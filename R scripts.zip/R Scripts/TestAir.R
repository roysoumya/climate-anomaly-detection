
#Adding row no. and column no. for ease of discovering spatial neighbours
row_no = NULL
col_no = NULL
grid_name = seq(1,225,1)

for (i in 1:15) {
  for (j in 1:15) {
    row_no = c(row_no,i)
    col_no = c(col_no,j)
  }
}
row_col = cbind(grid_name,row_no,col_no)
row_col_fr = as.data.frame(row_col)

#Adding parameter value
add_param = function(st_read=NULL,param=NULL){
  read_data = read.csv(st_read,header = TRUE, row.names = 1)
  parameter = rep(param,nrow(read_data))
  read_data = cbind(read_data,parameter)
  return(read_data)
}

read_data1 = add_param('925_hpa_Air_Temp_Spatio_Temporal_Anomaly.csv','air_temp')
read_data2 = add_param('925_hpa_Rel_Humid_Spatio_Temporal_Anomaly.csv','rel_humid')
read_data3 = add_param('925_hpa_UWind_Spatio_Temporal_Anomaly.csv','uwind')
read_data4 = add_param('925_hpa_VWind_Spatio_Temporal_Anomaly.csv','vwind')
read_data5 = add_param('925_hpa_Omega_Spatio_Temporal_Anomaly.csv','omega')



read

total_data = rbind(read_data1,read_data2,read_data3,read_data4,read_data5)

calendar_data = read.csv('~/R/Twitter India/Utility Files/Calendar_1951_to_2014.csv',header = TRUE, row.names = 1)

total_data1 = merge(total_data,calendar_data, by='index',all.x = TRUE)

loca = read.csv("~/R/Twitter India/Utility Files/Cleaned Location.csv",header = TRUE,row.names = 1)

total_data2 = merge(total_data1,loca,by='grid_name',all.x = TRUE)

#Adding the absolute value of the variables
#---------------------------------------------

#For the corresponding anomalies, determine the absolute value of the climatological variables
#Reading values from dataset values
air_data_2d = read.csv("Temp_925_1951_1980_Data_2D.csv",header=TRUE,row.names=1)
uwind_data_2d = read.csv("Uwind_925_1_Data_2D.csv",header=TRUE,row.names=1)
rel_humid_data_2d = read.csv("Relative_Hum_925_1_Data_2D.csv",header=TRUE,row.names=1)
vwind_data_2d = read.csv("Vwind_925_1_Data_2D.csv",header=TRUE,row.names=1)
omega_data_2d = read.csv("Omega_925_1_Data_2D.csv",header = TRUE,row.names=1)

air_data_2d = rbind(air_data_2d,read.csv("Temp_925_1981_2014_Data_2D.csv",header=TRUE,row.names=1))
uwind_data_2d = rbind(uwind_data_2d,read.csv("Uwind_925_2_Data_2D.csv",header=TRUE,row.names=1))
rel_humid_data_2d = rbind(rel_humid_data_2d,read.csv("Relative_Hum_925_2_Data_2D.csv",header=TRUE,row.names=1))
vwind_data_2d = rbind(vwind_data_2d,read.csv("Vwind_925_2_Data_2D.csv",header=TRUE,row.names=1))
omega_data_2d = rbind(omega_data_2d,read.csv("Omega_925_2_Data_2D.csv",header = TRUE,row.names=1))

num_of_row1 = nrow(total_data2)
omega_value = NULL
air_temp_value = NULL
uwind_value = NULL
vwind_value = NULL
rel_humid_value = NULL

for (i in 1:num_of_row1) {
  co_l = total_data2[i,1]
  ro_w = total_data2[i,2]
  omega_value[i] = omega_data_2d[ro_w,co_l]
  air_temp_value[i] = air_data_2d[ro_w,co_l]
  uwind_value[i] = uwind_data_2d[ro_w,co_l]
  vwind_value[i] = vwind_data_2d[ro_w,co_l]
  rel_humid_value[i] = rel_humid_data_2d[ro_w,co_l]
}


complete_data = cbind(total_data2,air_temp_value,uwind_value,vwind_value,rel_humid_value,omega_value)

write.csv(complete_data,file = 'Twitter_Anomaly_925hpa_Database.csv')

abso_value = function(data_plus_place,st_read=NULL){
  air_data = read.csv(st_read,header = TRUE,row.names = 1)
  air_temp_value =NULL
  number_of_row = nrow(data_plus_place)
  for (i in 1:number_of_row) {
    co_l = data_plus_place[i,1]
    ro_w = data_plus_place[i,2]
    air_temp_value[i] = data_plus_place[ro_w,co_l]
  }
  return(air_temp_value)
}

air_temp_value = abso_value(total_data2,'~/R/KGP/Original Data inCSV/Air_Data_2D.csv')
uwind_temp_value = abso_value(total_data2,'~/R/KGP/Original Data inCSV/Uwind_Data_2D.csv')
vwind_temp_value = abso_value(total_data2,'~/R/KGP/Original Data inCSV/Vwind_Data_2D.csv')
rel_humid_temp_value = abso_value(total_data2,'~/R/KGP/Original Data inCSV/Rel_Humid_Data_2D.csv')
sp_humid_temp_value = abso_value(total_data2,'~/R/KGP/Original Data inCSV/Sp_Humid_Data_2D.csv')













#---------------------------------------------------------------------------------------------------------





#next Test of spatio-temporal Anomaly
#Starting Spatio-temporal clustering
total_data = read.csv('300_hpa_Air_Temp_Spatial_Clustering.csv', header = TRUE,row.names=1)
sp_temp_clus_no = total_data$spatial_clus_no

mod_data4 = cbind(total_data,sp_temp_clus_no)
number_of_row = nrow(total_data)
#Adding another column known as anomaly id
anomaly_id  = seq(1,number_of_row,1)
mod_data4 = cbind(anomaly_id,mod_data4)

#Creating a list of vectors where the size of the list = 92159 and each element of the list is a vector containing 
#all the anomaly nos

seperate_tab = select(mod_data4, anomaly_id,grid_name,index,temp_cluster_no,spatial_clus_no)
seperate_tab = seperate_tab %>% arrange(temp_cluster_no)
unique_time = nrow(unique(as.data.frame(seperate_tab$temp_cluster_no)))
#List of vectors created and is complete
temp_hash = vector("list",unique_time)

create_list = seperate_tab[1,1] #Saving the anomaly id in the hash table
prev = seperate_tab[1,4] #Stores the temporal cluster no.

for (i in 2:number_of_row) {
  #Generating list of vectors 
  if(seperate_tab[i,4] == prev){
    create_list = c(create_list,seperate_tab[i,1])
    prev = seperate_tab[i,4]
  }
  else{
    temp_hash[[prev]] = create_list
    create_list = seperate_tab[i,1]
    prev = seperate_tab[i,4]
  }
}

temp_sp_clus_no = mod_data4$spatial_clus_no
mod_data4 = cbind(mod_data4,temp_sp_clus_no)

#Using the list of vectors generated and stored in temp_hash, we perform spatio-temporal clustering
flag_cnt = rep(0,number_of_row)

for (i in 1:number_of_row) {
  if(flag_cnt[i] == 0){
    temp_list = temp_hash[[mod_data4[i,4]]]
    curr_temp_sp_clus = mod_data4[i,10]
    for (j in 1:length(temp_list)) {
      loc = temp_list[j]
      mod_data4[loc,10] = curr_temp_sp_clus
      flag_cnt[loc] = 1
    }
  }
}

#Compaction required for the spatio-temporal cluster no

#Sorting according to the sp_cluster_no
sp_arrangement = mod_data4 %>% arrange(temp_sp_clus_no)
temp_sp_cluster1 = sp_arrangement$temp_sp_clus_no

temp_sp_clus = NULL
curr_cnt = 1

#Initial step
temp_sp_clus[1] = curr_cnt

for (i in 2:number_of_row) {
  if(temp_sp_cluster1[i] == temp_sp_cluster1[i-1]){
    temp_sp_clus[i] = curr_cnt
  }
  else{
    curr_cnt = curr_cnt + 1
    temp_sp_clus[i] = curr_cnt
  }
}

temp_sp_cluster_no = temp_sp_clus
sp_arrangement = select(sp_arrangement, -temp_sp_clus_no)
spatial_arrangement = cbind(sp_arrangement,temp_sp_cluster_no)
spatial_arrangement = select(spatial_arrangement,-sp_temp_clus_no)

write.csv(spatial_arrangement,'Air_Temp_Spatio_Temporal_Anomaly.csv')
