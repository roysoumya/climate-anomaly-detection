#Loading required libraries
library(RNetCDF)

#Removing all elements from workspace
rm(list=ls())

#Reading values from air_data_2d and uwind_data_2d
air_data_2d = read.csv("Air_Land.csv",header=TRUE,row.names=1)

library(in2extRemes)
air_land = as.in2extRemesDataObject(air_data_2d)

in2extRemes()

x=seq(1,15340,1)
plot(x,corr_air_sp_humid_frame2$corr_air_sp_humid,type ="l",col ="red",ylim = c(-0.8,0.8))
lines(x,corr_air_sp_humid_frame2$corr_sp_humid_uwnd,type = "l",col="green")

plot(x,corr_air_sp_humid_frame2$corr_air_sp_humid,type ="l",col ="red",ylim = c(-1.0,1.0))
lines(x,corr_air_sp_humid_frame2$corr_sp_humid_uwnd,type = "l",col="green")
lines(x,corr_air_sp_humid_frame2$corr_air_uwnd,type = "l",col="blue",lwt=2.0)

#Reading values from air_data_2d and uwind_data_2d
air_data_2d_spatial = read.csv("Corr_Land_Combined_Spatial.csv",header=TRUE,row.names=1)
hist(air_data_2d_spatial$corr_air_uwnd)

#Creating 3-d plot of correlation of Air-UWind values
#Reading values from air_data_2d and uwind_data_2d
air_data_2d = read.csv("Air_Data_2D.csv",header=TRUE,row.names=1)
uwind_data_2d = read.csv("Uwind_Data_2D.csv",header=TRUE,row.names=1)

#Set 1:Air
#Generating all the correlation values of each pair of air_temp and U-Wind
corr_air_uwnd=0
for(i in 1:925)
{
  corr_air_uwnd[i] = cor(air_data_2d[i],uwind_data_2d[i]) 
}

corr_air_uwnd_t=t(matrix(corr_air_uwnd,nrow = 37,ncol=25))

#Creating seperate file storing individual parameteres accordiing to lat-long coordinates
cor_air_uwnd = as.data.frame(t(matrix(corr_air_uwnd,nrow = 37,ncol=25)))

#Naming the rows and columns
xstor = seq(30,120,2.5)
ystor = seq(30,-30,-2.5)

r=raster(list(x=ystor,y=xstor,z=corr_air_uwnd_t))

new_xstor=NULL
for (i in 1:37) {
  new_xstor[i]=paste(xstor[i],'degE',sep = "")
}

new_ystor=NULL
for (i in 1:25) {
  new_ystor[i]=paste(ystor[i],'degN',sep = "")
}

names(cor_air_uwnd)=new_xstor
row.names(cor_air_uwnd)=new_ystor

#Writing the matrix
write.csv(cor_air_uwnd,file = "Cor_Air_UWind_3D.csv")



col_gen=NULL
for (i in 1:25) {
  col_gen = c(col_gen,seq(1,37,1))
}

row_gen=NULL
for (i in 1:25) {
  for (j in 1:37) {
    row_gen = c(row_gen,i)
  }
}
row_gen_fr = as.data.frame(row_gen)
col_gen_fr =as.data.frame(col_gen)

cor_tot_first = read.csv("Corr_Last10_Combined.csv",header=TRUE,row.names=1)
cor_tot_first=data.frame(row_gen_fr,col_gen_fr,cor_tot_first)

scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_air_uwnd ,pch=15,main="Air_UWind_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_rel_humid_sp_humid ,pch=15,main="Sp_Rel_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_air_rel_humid ,pch=15,main="Air_Rel_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_air_sp_humid ,pch=15,main="Air_Sp_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_air_vwnd ,pch=15,main="Air_VWind_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_rel_humid_uwnd ,pch=15,main="UWind_Rel_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_uwnd_vwnd ,pch=15,main="UWind_VWind_Correlation Last 10")
scatter2D(cor_tot_first$col_gen,cor_tot_first$row_gen,colvar = cor_tot_first$corr_rel_humid_vwnd ,pch=15,main="VWind_Rel_Correlation Last 10")

scatter2D(Grid_Sp_Rel$col_gen,Grid_Sp_Rel$row_gen,colvar = cor_tot_first$corr_rel_humid_vwnd ,pch=15,main="VWind_Rel_Correlation")

Grid_Sp_Rel = data.frame(row_gen_fr,col_gen_fr,cor_tot$corr_rel_humid_sp_humid)

